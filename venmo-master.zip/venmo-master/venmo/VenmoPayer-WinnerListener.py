########################CHANGE FOR GOOGLE CLOUD
import firebase_admin
from time import sleep
from firebase_admin import credentials
from firebase_admin import firestore
import json
import os

# Use a service account
cred = credentials.Certificate('key.json')
firebase_admin.initialize_app(cred)

db = firestore.client()
########################

from payment import *
#pay("@austin-mac",0.01,"you win")

users_ref = db.collection(u'drops')
docs = users_ref.stream()

OGDropWinners = []
OGdropIDs = []
OGdropDataPlusIds = []

for drop in docs:
    try:
        OGDropWinners.append(drop.to_dict()["winner"])
        OGDropWinners.append(drop.id)
        OGdropDataPlusIds.append((drop.to_dict()["winner"],drop.id))
    except:
        continue

print(OGdropDataPlusIds)

while True:
    sleep(10)
    #query server for new drops
    users_ref = db.collection(u'drops')
    docs = users_ref.stream()
    dropData = []
    dropIDs = []
    for drop in docs:
        if (drop.id in OGdropIDs) and ((drop.to_dict()["winner"],drop.id) not in OGdropDataPlusIds): #there was a winner
            try:
                index = OGdropDataPlusIds.index(('',drop.id)) #index of the winner
                OGdropDataPlusIds[index] = ((drop.to_dict()["winner"],drop.id)) #update the OGData to reflect the winner
                OGDropWinners[index] = drop.to_dict()["winner"]
                winner = "@" + drop.to_dict()["winner"]
                print("the winner is: " + winner)
                try:
                    os.system("venmo pay " + winner + " 0.01 for the" + drop.to_dict()["name"])
                    pay(winner,0.01,drop["name"])
                except:
                    print("please update the config file")
                    continue
            except:
                continue
        if (drop.id not in OGdropIDs): #new drop
            OGdropDataPlusIds.append((drop.to_dict()["winner"],drop.id))
            OGdropIDs.append(drop.id)
            OGDropWinners.append(drop.to_dict()["winner"])
    print("updating data....")
